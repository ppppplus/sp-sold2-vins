Binary descriptors for lines extracted from an image
====================================================